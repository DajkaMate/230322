<?php
    include("includes/header.php");
    $username = ""; $email = ""; $password = ""; $error = false;
    $message = array("username" => "", "email" => "", "password" => "");
    if(isset($_POST["submit"])){
        //User
        if(empty($_POST["username"])){
            $message["username"] = "Username field empty!!!";
        }
        //Emil
        if(empty($_POST["email"])){
            $message["email"] = "E-mail field empty!!!";
        } else {
            $email = $_POST["email"];
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $message["email"] = "Invalid email format!!!";
              }
        }
        //Pass
        if(empty($_POST["password"])){
            $message["password"] = "Password field empty!!!";
        } else {
            $password = $_POST["password"];
            if (!preg_match_all('$\S*(?=\S{8,})(?=\S*[a-z])(?=\S*[A-Z])(?=\S*[\d])\S*$', $password)){
                $message["password"] = "Password is not a valid password!!!";  
            }
        }
        //Redirect
        if(array_filter($message)){
            $error = true;
        } else {
            $username = $_POST["username"];
            $password = hash('md5',$password);
            AddUser($username,$email,$password);
            header("Location: login.php");
        }
    }
?>
    <main class="container py-3">
        <div class="card m-auto mycard">
            <div class="card-body">
                <h6>Registry</h6>
                <?php if($error == true){ ?> 
                    <?php if($message["username"] != ""){ ?>
                        <p class="bg-danger text-white p-3">
                            <?php echo $message["username"]; ?>
                        </p>
                    <?php } ?>
                    <?php if($message["email"] != ""){ ?>
                        <p class="bg-danger text-white p-3">
                            <?php echo $message["email"]; ?>
                        </p>
                    <?php } ?>
                    <?php if($message["password"] != ""){ ?>
                        <p class="bg-danger text-white p-3">
                            <?php echo $message["password"]; ?>
                        </p>
                    <?php } ?>
                <?php } ?>
                <form action="reg.php" method="post">
                    <div class="py-2">
                        <label class="form-label" for="username">Username:</label>
                        <input class="form-control" type="text" name="username" 
                        placeholder="Like: Lakatos.Brendon" value="<?php echo $username; ?>">
                    </div>
                    <div class="py-2">
                        <label class="form-label" for="email">E-mail:</label>
                        <input class="form-control" type="text" name="email" 
                        placeholder="Like: brendon@cia.com" value="<?php echo $email; ?>">
                    </div>
                    <div class="py-2">
                        <label class="form-label" for="password">Password:</label>
                        <input class="form-control" type="password" name="password" 
                        placeholder="Like: Appletree123" value="<?php echo $password; ?>">
                    </div>
                    <div class="py-2 text-center">
                        <button class="btn btn-primary" type="submit" name="submit">
                            REGISTRY
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </main>
<?php
    include("includes/footer.php");
?>