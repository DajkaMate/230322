<?php
    function Connect(){
        $szerver    = "localhost";
        $user       = "root";
        $pass       = "";
        $DB         = "login";

        $con = mysqli_connect($szerver,$user,$pass,$DB);

        if(!$con){
            die("Baj van");
        }
        return $con;
    }
?>