<?php
    function AddUser($username,$email,$password){
        $con = Connect();
        $sql = "INSERT INTO user (username,email,pass)
                VALUES ('$username', '$email', '$password')";
        mysqli_query($con,$sql);
        mysqli_close($con);
    }
    function LoginUser($username,$password){
        $con = Connect();
        $sql = "SELECT username, pass FROM user 
                WHERE '$username'=username AND '$password'=pass";
        $result = mysqli_query($con,$sql);
        return mysqli_num_rows($result);
        mysqli_close($con);
    }

?>