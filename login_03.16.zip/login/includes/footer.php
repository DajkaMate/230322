    <footer>
        <p class="text-center">Footer text</p>
    </footer>
</body>
</html>