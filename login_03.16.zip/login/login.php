<?php
    include("includes/header.php");
    $username = ""; $password = ""; $error = false;
    $message = array("username" => "", "password" => "", "loginerror" => "");
    if(isset($_POST["login"])){
        //User
        if(empty($_POST["username"])){
        $message["username"] = "Username field empty!!!";
        }
        //Pass
        if(empty($_POST["password"])){
            $message["password"] = "Password field empty!!!";
        } 
        //Redirect
        if(array_filter($message)){
            $error = true;
        } else {
            $username = $_POST["username"];
            $password = $_POST["password"];
            $password = hash('md5',$password);
            $sv = LoginUser($username,$password);
            echo $sv;
            ///header("Location: ./");
        }
    }
?>
    <main class="container py-3">
        <div class="card m-auto mycard">
            <div class="card-body">
                <h6>Login</h6>
                <?php if($error == true){ ?> 
                    <?php if($message["username"] != ""){ ?>
                        <p class="bg-danger text-white p-3">
                            <?php echo $message["username"]; ?>
                        </p>
                    <?php } ?>
                    <?php if($message["password"] != ""){ ?>
                        <p class="bg-danger text-white p-3">
                            <?php echo $message["password"]; ?>
                        </p>
                    <?php } ?>
                    <?php if($message["loginerror"] != ""){ ?>
                        <p class="bg-danger text-white p-3">
                            <?php echo $message["loginerror"]; ?>
                        </p>
                    <?php } ?>
                <?php } ?>
                <form action="login.php" method="post">
                    <div class="py-2">
                        <label class="form-label" for="username">Username:</label>
                        <input class="form-control" type="text" name="username" 
                        placeholder="Like: Lakatos.Brendon" value="<?php echo $username; ?>">
                    </div>
                    <div class="py-2">
                        <label class="form-label" for="password">Password:</label>
                        <input class="form-control" type="password" name="password" 
                        placeholder="Like: Appletree123">
                    </div>
                    <div class="py-2 text-center">
                        <button class="btn btn-primary" type="submit" name="login">
                            LOGIN
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </main>
<?php
    include("includes/footer.php");
?>