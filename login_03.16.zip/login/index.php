<?php
    include("includes/header.php");
?>
    <main class="container py-3">
        <p>Ha bejelentkezel, akkor látsz itt egy cuki képet</p>
    </main>
<?php
    include("includes/footer.php");
?>